﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Task1_3_Tier_App
{
    public class dal
    {
        public int U_id { get; set; }
        public string U_name { get; set; }
        public string U_password { get; set; }
    }
}